from collections.abc import Callable
from typing import List, Tuple
from collections import deque

from game import board, move, enums
from game.enums import Cell, CARPET_POINTS_TABLE, MoveType, Direction, loc_after_direction
from .rat_belief import RatBelief


# ---------------------------------------------------------------------------
# Albert-killer: zero searches, pure carpet efficiency
# ---------------------------------------------------------------------------
TIME_BUFFER = 5.0
HISTORY_LEN = 6
_FOUR_DIRS = [(1, 0), (-1, 0), (0, 1), (0, -1)]


class PlayerAgent:
    """
    v7.0-ALBERT — Optimized to beat Albert/Albert Lite.
    
    Albert never searches for the rat. Albert wins by:
    - Priming efficiently (18-22 primes/game)
    - Carpeting long runs (avg 7+ carpets, 21+ carpet pts)
    - Never wasting turns on rat searches
    
    Our counter-strategy:
    - NEVER search for the rat (0 searches)
    - Maximize primes per game (target 20+)
    - Build long primed lines and carpet them fast
    - Carpet aggressively — take length 2+ immediately
    - Higher carpet potential weight to navigate toward runs
    """

    def __init__(self, board, transition_matrix=None, time_left: Callable = None):
        self.hmm = RatBelief(transition_matrix)
        self.pos_history = deque(maxlen=HISTORY_LEN)

    def commentate(self):
        return "AKIR-v7.1-ALBERT"

    def play(self, board, sensor_data: Tuple, time_left: Callable):
        noise, est_d = sensor_data
        my_pos = board.player_worker.get_location()

        # Still update HMM (costs nothing, useful if we ever need it)
        self.hmm.update(board, noise, est_d, my_pos, board.opponent_search)

        turns_left = board.player_worker.turns_left

        # --- NEVER search for the rat ---
        # Every turn must be prime, carpet, or plain (and minimize plain)

        valid_moves = board.get_valid_moves(enemy=False, exclude_search=True)
        if not valid_moves:
            # Truly stuck — forced search as last resort
            best_idx, _ = self.hmm.get_best_guess()
            self.pos_history.append(my_pos)
            x, y = best_idx % 8, best_idx // 8
            return move.Move.search((x, y))

        # --- Greedy: take ANY carpet with positive value ---
        # This is the key anti-Albert strategy: carpet immediately,
        # don't let opponent steal our primed squares
        best_carpet = None
        best_carpet_pts = 0
        for m in valid_moves:
            if m.move_type == MoveType.CARPET:
                pts = CARPET_POINTS_TABLE.get(m.roll_length, 0)
                if pts > best_carpet_pts:
                    best_carpet_pts = pts
                    best_carpet = m
        if best_carpet_pts >= 2:  # length 2+ (positive value)
            self.pos_history.append(my_pos)
            return best_carpet

        # --- Alpha-beta search ---
        valid_moves = self._order_moves(valid_moves)

        available = time_left() - TIME_BUFFER
        if available < 1.0:
            self.pos_history.append(my_pos)
            return valid_moves[0]

        time_per_turn = available / max(turns_left, 1)
        turn_budget = min(time_per_turn * 0.85, 6.0)
        deadline = time_left() - turn_budget

        best_move = valid_moves[0]
        for depth in range(2, 30):
            if time_left() < deadline + 0.05:
                break
            result = self._search_root(board, valid_moves, depth, time_left, deadline)
            if result is not None:
                best_move = result
            else:
                break

        self.pos_history.append(my_pos)
        return best_move

    # ------------------------------------------------------------------
    # Alpha-Beta
    # ------------------------------------------------------------------

    def _search_root(self, board, moves, depth, time_left, deadline):
        best_move = None
        best_score = float('-inf')
        alpha = float('-inf')
        beta = float('inf')
        hist = list(self.pos_history)
        for m in moves:
            if time_left() < deadline:
                return None
            child = board.forecast_move(m, check_ok=False)
            if child is None:
                continue
            score = self._min_value(child, alpha, beta, depth - 1, time_left, deadline)
            if score is None:
                return None
            dest = child.player_worker.get_location()
            if len(hist) >= 2 and dest == hist[-2]:
                score -= 25.0
            elif len(hist) >= 3 and dest == hist[-3]:
                score -= 15.0
            if score > best_score:
                best_score = score
                best_move = m
            alpha = max(alpha, best_score)
        return best_move

    def _max_value(self, board, alpha, beta, depth, time_left, deadline):
        if time_left() < deadline:
            return None
        if depth == 0:
            return self._evaluate(board)
        moves = board.get_valid_moves(enemy=False, exclude_search=True)
        if not moves:
            return self._evaluate(board)
        moves = self._order_moves(moves)
        best = float('-inf')
        for m in moves:
            if time_left() < deadline:
                return None
            child = board.forecast_move(m, check_ok=False)
            if child is None:
                continue
            val = self._min_value(child, alpha, beta, depth - 1, time_left, deadline)
            if val is None:
                return None
            best = max(best, val)
            alpha = max(alpha, best)
            if alpha >= beta:
                break
        return best

    def _min_value(self, board, alpha, beta, depth, time_left, deadline):
        if time_left() < deadline:
            return None
        if depth == 0:
            return self._evaluate(board)
        board.reverse_perspective()
        opp_moves = board.get_valid_moves(enemy=False, exclude_search=True)
        opp_moves = self._order_moves(opp_moves)
        if not opp_moves:
            board.reverse_perspective()
            return self._evaluate(board)
        worst = float('inf')
        for em in opp_moves:
            if time_left() < deadline:
                board.reverse_perspective()
                return None
            child = board.forecast_move(em, check_ok=False)
            if child is None:
                continue
            child.reverse_perspective()
            val = self._max_value(child, alpha, beta, depth - 1, time_left, deadline)
            if val is None:
                board.reverse_perspective()
                return None
            worst = min(worst, val)
            beta = min(beta, worst)
            if alpha >= beta:
                break
        board.reverse_perspective()
        return worst

    # ------------------------------------------------------------------
    # Move ordering — carpet first, then prime, plain last
    # ------------------------------------------------------------------

    def _order_moves(self, moves):
        def priority(m):
            if m.move_type == MoveType.CARPET:
                pts = CARPET_POINTS_TABLE.get(m.roll_length, 0)
                return (0, -pts) if pts > 0 else (4, 0)
            elif m.move_type == MoveType.PRIME:
                return (1, 0)
            else:
                return (2, 0)
        return sorted(moves, key=priority)

    # ------------------------------------------------------------------
    # Evaluation — carpet-maximizing, no rat component
    # ------------------------------------------------------------------

    def _evaluate(self, board):
        my_pts = board.player_worker.get_points()
        opp_pts = board.opponent_worker.get_points()
        turns_left = board.player_worker.turns_left
        my_pos = board.player_worker.get_location()
        opp_pos = board.opponent_worker.get_location()

        # 1. Point differential — heavily weighted late game
        late = turns_left <= 15
        score = (3.0 if late else 1.0) * float(my_pts - opp_pts)

        time_w = turns_left / 40.0 + 0.5

        # 2. Carpet potential — MASSIVE weight
        #    The #1 thing that beats Albert is carpeting efficiently
        my_cp = self._carpet_value(board, my_pos)
        opp_cp = self._carpet_value(board, opp_pos)
        score += 3.0 * time_w * (my_cp - opp_cp)

        # 3. Can-prime bonus
        if board.get_cell(my_pos) == Cell.SPACE:
            score += 1.0 * time_w
        if board.get_cell(opp_pos) == Cell.SPACE:
            score -= 1.0 * time_w

        # 4. Extension potential — but REDUCED weight
        #    We don't want to over-extend lines; carpet them instead
        my_ext = self._extension_potential(board, my_pos)
        opp_ext = self._extension_potential(board, opp_pos)
        score += 0.5 * time_w * (my_ext - opp_ext)

        # 5. Carpet urgency — penalize when opponent can carpet our runs
        my_threatened = self._threatened_primes(board, my_pos, opp_pos)
        score -= 1.0 * my_threatened  # BOOSTED from 0.5

        # 6. Opponent constraint
        opp_blocked = self._constraint(board, opp_pos)
        my_blocked = self._constraint(board, my_pos)
        score += 0.3 * (opp_blocked - my_blocked)

        return score

    # ------------------------------------------------------------------
    # Heuristic helpers
    # ------------------------------------------------------------------

    def _carpet_value(self, board, pos):
        """Sum of carpet values for all runs >= 2 adjacent to pos."""
        total = 0.0
        x, y = pos
        for dx, dy in _FOUR_DIRS:
            run = 0
            nx, ny = x + dx, y + dy
            while 0 <= nx < 8 and 0 <= ny < 8:
                if board.get_cell((nx, ny)) == Cell.PRIMED:
                    run += 1
                    nx += dx
                    ny += dy
                else:
                    break
            if run >= 2:
                total += CARPET_POINTS_TABLE.get(run, 0)
        return total

    def _extension_potential(self, board, pos):
        """If on SPACE, how long could a primed line through here become?"""
        x, y = pos
        if board.get_cell((x, y)) != Cell.SPACE:
            return 0.0
        best = 0.0
        for dx, dy in [(1, 0), (0, 1)]:
            behind = 0
            bx, by = x - dx, y - dy
            while 0 <= bx < 8 and 0 <= by < 8 and board.get_cell((bx, by)) == Cell.PRIMED:
                behind += 1
                bx -= dx
                by -= dy
            ahead = 0
            fx, fy = x + dx, y + dy
            while 0 <= fx < 8 and 0 <= fy < 8 and board.get_cell((fx, fy)) == Cell.PRIMED:
                ahead += 1
                fx += dx
                fy += dy
            total_line = behind + 1 + ahead
            if total_line >= 2:
                pts = CARPET_POINTS_TABLE.get(min(total_line, 7), 0)
                if pts > best:
                    best = float(pts)
        return best

    def _threatened_primes(self, board, my_pos, opp_pos):
        """
        How many of our carpetable primed runs can the opponent also reach?
        If opponent is adjacent to a primed run we could carpet, that's urgent.
        """
        ox, oy = opp_pos
        threat = 0.0
        for dx, dy in _FOUR_DIRS:
            run = 0
            nx, ny = ox + dx, oy + dy
            while 0 <= nx < 8 and 0 <= ny < 8:
                if board.get_cell((nx, ny)) == Cell.PRIMED:
                    run += 1
                    nx += dx
                    ny += dy
                else:
                    break
            if run >= 2:
                threat += CARPET_POINTS_TABLE.get(run, 0)
        return threat

    def _constraint(self, board, pos):
        """Count blocked cardinal neighbors."""
        x, y = pos
        blocked = 0
        for dx, dy in _FOUR_DIRS:
            nx, ny = x + dx, y + dy
            if nx < 0 or nx >= 8 or ny < 0 or ny >= 8:
                blocked += 1
            elif board.get_cell((nx, ny)) in (Cell.BLOCKED, Cell.PRIMED):
                blocked += 1
        return blocked
